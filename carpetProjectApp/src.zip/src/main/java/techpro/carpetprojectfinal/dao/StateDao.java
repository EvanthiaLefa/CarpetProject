package techpro.carpetprojectfinal.dao;

import techpro.carpetprojectfinal.entity.State;

import java.util.List;

public interface StateDao {
        List<State> findAllStates();

}
