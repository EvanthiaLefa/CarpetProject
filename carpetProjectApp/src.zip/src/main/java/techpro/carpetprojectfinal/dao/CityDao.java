package techpro.carpetprojectfinal.dao;

import techpro.carpetprojectfinal.entity.City;

import java.util.List;

public interface CityDao {
    List<City> findAllCities();
}
